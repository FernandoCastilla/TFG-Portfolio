<?php $__env->startSection('content'); ?>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js'></script>

    <div class="mb-4">
        <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['links' => [
            ['label' => 'Panel Global', 'url' => url('/')],
            ['label' => 'Calendario de Tareas', 'url' => null],
        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['links' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            ['label' => 'Panel Global', 'url' => url('/')],
            ['label' => 'Calendario de Tareas', 'url' => null],
        ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
    </div>

    <div class="max-w-7xl mx-auto">
        <div class="mb-6">
            <h1 class="text-3xl font-bold text-gray-800 dark:text-white">Calendario de Work Packages</h1>
            <p class="text-gray-600 dark:text-gray-400">Vista temporal de todas las tareas planificadas en los proyectos.</p>
        </div>

        <div class="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
            <div class="flex gap-4 mb-4 text-sm text-gray-700 dark:text-gray-300">
                <div class="flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-blue-500"></span> Nuevas</div>
                <div class="flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-green-500"></span> En progreso</div>
                <div class="flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-gray-500"></span> Cerradas</div>
            </div>
            <div id='calendar'></div>
        </div>
    </div>

    
    <style>
        .dark .fc { color: #e5e7eb; }
        .dark .fc-theme-standard td, .dark .fc-theme-standard th { border-color: #374151; }
        .dark .fc-theme-standard .fc-scrollgrid { border-color: #374151; }
        .dark .fc-col-header-cell { background-color: #1f2937; }
        .dark .fc-daygrid-day { background-color: #111827; }
        .dark .fc-daygrid-day:hover { background-color: #1f2937; }
        .dark .fc-day-today { background-color: #312e81 !important; }
        .dark .fc-button-primary { background-color: #4f46e5 !important; border-color: #4338ca !important; }
        .dark .fc-button-primary:hover { background-color: #4338ca !important; }
        .dark .fc-button-primary:not(:disabled).fc-button-active { background-color: #3730a3 !important; }
        .dark .fc-toolbar-title { color: #f9fafb; }
        .dark .fc-daygrid-day-number { color: #9ca3af; }
        .dark .fc-col-header-cell-cushion { color: #d1d5db; }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var calendarEl = document.getElementById('calendar');
            var eventos = <?php echo json_encode($eventos); ?>;

            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                locale: 'es',
                firstDay: 1,
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,listMonth'
                },
                buttonText: { today: 'Hoy', month: 'Mes', week: 'Semana', list: 'Lista' },
                events: eventos,
                eventClick: function (info) {
                    window.location.href = info.event.url;
                    info.jsEvent.preventDefault();
                }
            });
            calendar.render();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/calendario.blade.php ENDPATH**/ ?>