<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sync_logs', function (Blueprint $table) {
            $table->id();
            $table->dateTime('ejecutado_en');
            $table->float('duracion_segundos');
            $table->integer('proyectos_api');
            $table->integer('tareas_api');
            $table->integer('proyectos_nuevos');
            $table->integer('tareas_nuevas');
            $table->integer('proyectos_total');
            $table->integer('tareas_total');
            $table->string('estado');
            $table->text('mensaje_error')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sync_logs');
    }
};
