<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Cache;

class ActualizarDatosUGR extends Command
{
    protected $signature = 'ugr:update';
    
    protected $description = 'Descarga datos de la API de la UGR y los fusiona con los locales (sin borrar los de prueba)';

    public function handle()
    {
        $baseUrl = env('OPENPROJECT_URL') . '/api/v3';
        $token = env('OPENPROJECT_TOKEN');

        if (!$token) {
            $this->error('❌ Token incorrecto o no definido en el archivo .env');
            return; // Salimos para que no intente conectar y dé error
        }

        $this->info('Iniciando sincronización con la UGR...');

        // 1. DESCARGAR DATOS DE LA API 
        $this->info('Descargando proyectos y tareas...');
        $resProyectos = Http::withBasicAuth('apikey', $token)->withoutVerifying()->get("$baseUrl/projects");
        $resTareas = Http::withBasicAuth('apikey', $token)->withoutVerifying()->get("$baseUrl/work_packages");
        
        if (!$resProyectos->successful() || !$resTareas->successful()) {
            $this->error('❌ Hubo un error al conectar con la API de la UGR.');
            Cache::forever('api_conectada', false);
            return;
        }

        // Convertimos las respuestas a arrays de PHP
        $proyectosApi = $resProyectos->json()['_embedded']['elements'] ?? [];
        $tareasApi = $resTareas->json()['_embedded']['elements'] ?? [];

        $this->info("-> Recibidos " . count($proyectosApi) . " proyectos y " . count($tareasApi) . " tareas de la API.");

        // 2. LEER DATOS LOCALES ACTUALES
        $this->info('Leyendo datos de prueba locales...');
        $rutaProyectos = storage_path('app/proyectos_ugr.json');
        $rutaTareas = storage_path('app/tareas_ugr.json');

        $dataProyectosLocales = File::exists($rutaProyectos) ? json_decode(File::get($rutaProyectos), true) : ['_embedded' => ['elements' => []]];
        $dataTareasLocales = File::exists($rutaTareas) ? json_decode(File::get($rutaTareas), true) : ['_embedded' => ['elements' => []]];

        $listaProyectosLocales = $dataProyectosLocales['_embedded']['elements'] ?? [];
        $listaTareasLocales = $dataTareasLocales['_embedded']['elements'] ?? [];

        // 3. FUSIONAR (Merge + Unique por ID)
        $this->info('Fusionando datos sin duplicados...');
        
        $coleccionProyectos = collect($listaProyectosLocales)->merge($proyectosApi)->unique('id')->values()->toArray();
        $coleccionTareas = collect($listaTareasLocales)->merge($tareasApi)->unique('id')->values()->toArray();

        // 4. GUARDAR EN LOS ARCHIVOS JSON
        $this->info('Guardando nuevos archivos...');
        
        $dataProyectosLocales['_embedded']['elements'] = $coleccionProyectos;
        $dataProyectosLocales['total'] = count($coleccionProyectos);
        
        $dataTareasLocales['_embedded']['elements'] = $coleccionTareas;
        $dataTareasLocales['total'] = count($coleccionTareas);

        File::put($rutaProyectos, json_encode($dataProyectosLocales, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        File::put($rutaTareas, json_encode($dataTareasLocales, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        Cache::forever('api_conectada', true);

        $this->info('✅ Proceso finalizado con éxito.');
        $this->line("Total en la web: " . count($coleccionProyectos) . " proyectos y " . count($coleccionTareas) . " tareas.");
    }
}