<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Barryvdh\DomPDF\Facade\Pdf;

class ProjectController extends Controller
{
    public function index(Request $request)
    {
        // 1. Recogemos todos los filtros del usuario
        $search = $request->input('search');
        $statusFilter = $request->input('status'); // 'active' o 'inactive'
        $visibilityFilter = $request->input('visibility'); // 'public' o 'private'

        $rutaArchivo = storage_path('app/proyectos_ugr.json');
        $proyectos = [];

        if (\Illuminate\Support\Facades\File::exists($rutaArchivo)) {
            $jsonCrudo = \Illuminate\Support\Facades\File::get($rutaArchivo);
            $datos = json_decode($jsonCrudo, true);
            $proyectos = $datos['_embedded']['elements'] ?? [];
        }

        // 2. Aplicamos TODOS los filtros a la vez
        $proyectos = array_filter($proyectos, function($proyecto) use ($search, $statusFilter, $visibilityFilter) {
            
            // Filtro 1: Texto (Nombre)
            $coincideTexto = true;
            if ($search) {
                $coincideTexto = stripos($proyecto['name'], $search) !== false;
            }

            // Filtro 2: Estado (Activo/Inactivo)
            $coincideEstado = true;
            if ($statusFilter === 'active') {
                $coincideEstado = $proyecto['active'] === true;
            } elseif ($statusFilter === 'inactive') {
                $coincideEstado = $proyecto['active'] === false;
            }

            // Filtro 3: Visibilidad (Público/Privado)
            $coincideVisibilidad = true;
            if ($visibilityFilter === 'public') {
                $coincideVisibilidad = $proyecto['public'] === true;
            } elseif ($visibilityFilter === 'private') {
                $coincideVisibilidad = $proyecto['public'] === false;
            }

            // El proyecto solo sobrevive si cumple TODOS los filtros que el usuario haya puesto
            return $coincideTexto && $coincideEstado && $coincideVisibilidad;
        });

        // 3. Enviamos los proyectos filtrados y las variables a la vista (para que los selects no se borren)
        return view('proyectos.index', compact('proyectos', 'search', 'statusFilter', 'visibilityFilter'));
    }

    public function show($id)
    {
        $rutaArchivo = storage_path('app/proyectos_ugr.json');
        
        if (\Illuminate\Support\Facades\File::exists($rutaArchivo)) {
            $jsonCrudo = \Illuminate\Support\Facades\File::get($rutaArchivo);
            $datos = json_decode($jsonCrudo, true);
            $proyectos = $datos['_embedded']['elements'] ?? [];

            // Usamos las "Collections" de Laravel para buscar el proyecto con ese ID
            $proyecto = collect($proyectos)->firstWhere('id', (int)$id);

            // Si lo encontramos, cargamos la vista de detalles
            if ($proyecto) {
                return view('proyectos.show', compact('proyecto'));
            }
        }

        // Si no existe el ID o el archivo, devolvemos un error 404
        abort(404, 'Proyecto no encontrado');
    }

    public function tareas(Request $request, $id)
    {
        $rutaProyectos = storage_path('app/proyectos_ugr.json');
        $proyecto = null;
        if (\Illuminate\Support\Facades\File::exists($rutaProyectos)) {
            $proyectosData = json_decode(\Illuminate\Support\Facades\File::get($rutaProyectos), true);
            $proyecto = collect($proyectosData['_embedded']['elements'] ?? [])->firstWhere('id', (int)$id);
        }

        if (!$proyecto) {
            abort(404, 'Proyecto no encontrado');
        }

        $rutaTareas = storage_path('app/tareas_ugr.json');
        $tareas = [];
        $graficaLabels = [];
        $graficaDatos = [];
        
        // Variables para los filtros
        $tipos = collect();
        $estados = collect();
        $asignados = collect();
        
        $selectedSort = $request->query('sort');

        $selectedTipo = $request->query('tipo');
        $selectedEstado = $request->query('estado');
        $selectedAsignado = $request->query('asignado');
        $selectedSearch = $request->query('search');
        $selectedPrioridad = $request->query('prioridad');

        
        // Variables para el filtro de fechas
        $selectedYear = $request->query('year');
        $selectedMonth = $request->query('month');

        if (\Illuminate\Support\Facades\File::exists($rutaTareas)) {
            $tareasData = json_decode(\Illuminate\Support\Facades\File::get($rutaTareas), true);
            $todasLasTareas = $tareasData['_embedded']['elements'] ?? [];

            // Filtramos las tareas de este proyecto
            $tareas = array_filter($todasLasTareas, function($tarea) use ($id) {
                $enlaceProyecto = $tarea['_links']['project']['href'] ?? '';
                return str_ends_with($enlaceProyecto, '/' . $id);
            });

            // Extraemos todos los valores ÚNICOS para los desplegables
            $tipos = collect($tareas)->map(fn($t) => $t['_links']['type']['title'] ?? 'Desconocido')->unique()->sort()->values();
            $estados = collect($tareas)->map(fn($t) => $t['_links']['status']['title'] ?? 'Desconocido')->unique()->sort()->values();
            $asignados = collect($tareas)->map(fn($t) => $t['_links']['assignee']['title'] ?? 'Sin asignar')->unique()->sort()->values();
            $prioridades = collect($tareas)->map(fn($t) => $t['_links']['priority']['title'] ?? 'Normal')->unique()->sort()->values();

            // Aplicamos los filtros si el usuario ha seleccionado alguno
            if ($selectedTipo || $selectedEstado || $selectedAsignado || $selectedYear || $selectedMonth || $selectedSearch || $selectedPrioridad) {
                $tareas = array_filter($tareas, function($tarea) use ($selectedTipo, $selectedEstado, $selectedAsignado, $selectedYear, $selectedMonth, $selectedSearch, $selectedPrioridad) {
                    
                    // Comprobaciones de los filtros
                    $matchTipo = !$selectedTipo || ($tarea['_links']['type']['title'] ?? 'Desconocido') === $selectedTipo;
                    $matchEstado = !$selectedEstado || ($tarea['_links']['status']['title'] ?? 'Desconocido') === $selectedEstado;
                    $matchAsignado = !$selectedAsignado || ($tarea['_links']['assignee']['title'] ?? 'Sin asignar') === $selectedAsignado;
                    $matchPrioridad = !$selectedPrioridad || ($tarea['_links']['priority']['title'] ?? 'Normal') === $selectedPrioridad;

                    // Busqueda de texto en el nombre de la tarea
                    $matchSearch = true;
                    if (!empty($selectedSearch)) {
                        $subject = $tarea['subject'] ?? '';
                        // stripos devuelve false si no encuentra la palabra
                        if (stripos($subject, $selectedSearch) === false) {
                            $matchSearch = false;
                        }
                    }
                    
                    
                    // Comprobación de la lógica de fechas
                    $matchFecha = true;
                    if ($selectedYear) {
                        $fechaString = $tarea['startDate'] ?? $tarea['createdAt'] ?? null;
                        
                        if (!$fechaString) {
                            $matchFecha = false; // Si no tiene fecha, no la mostramos
                        } else {
                            $taskYear = date('Y', strtotime($fechaString));
                            $taskMonth = date('m', strtotime($fechaString));
                            
                            if ($selectedYear != $taskYear) {
                                $matchFecha = false;
                            } elseif ($selectedMonth && $selectedMonth != $taskMonth) {
                                $matchFecha = false;
                            }
                        }
                    }
                    
                    // Solo mantenemos la tarea si cumple TODOS los filtros activos
                    return $matchTipo && $matchEstado && $matchAsignado && $matchFecha && $matchSearch && $matchPrioridad;
                });
            }

            // Lógica de ordenación
            if (!empty($selectedSort)) {
                $tareasCollection = collect($tareas);

                switch ($selectedSort) {
                    case 'date_desc': // Más recientes primero
                        $tareas = $tareasCollection->sortByDesc(function($t) {
                            return $t['startDate'] ?? '0000-00-00';
                        })->values()->all();
                        break;
                    case 'date_asc': // Más antiguas primero
                        $tareas = $tareasCollection->sortBy(function($t) {
                            return $t['startDate'] ?? '9999-12-31';
                        })->values()->all();
                        break;
                    case 'progress_desc': // 100% a 0%
                        $tareas = $tareasCollection->sortByDesc(function($t) {
                            return $t['percentageDone'] ?? 0;
                        })->values()->all();
                        break;
                    case 'progress_asc': // 0% a 100%
                        $tareas = $tareasCollection->sortBy(function($t) {
                            return $t['percentageDone'] ?? 0;
                        })->values()->all();
                        break;
                    case 'name_asc': // A - Z
                        $tareas = $tareasCollection->sortBy(function($t) {
                            return strtolower($t['subject'] ?? '');
                        })->values()->all();
                        break;
                    case 'name_desc': // Z - A
                        $tareas = $tareasCollection->sortByDesc(function($t) {
                            return strtolower($t['subject'] ?? '');
                        })->values()->all();
                        break;
                }
            }

            // Logica de la gráfica
            $conteoEstados = [];
            foreach ($tareas as $tarea) {
                $estado = $tarea['_links']['status']['title'] ?? 'Desconocido';
                if (!isset($conteoEstados[$estado])) {
                    $conteoEstados[$estado] = 0;
                }
                $conteoEstados[$estado]++;
            }

            $graficaLabels = array_keys($conteoEstados);
            $graficaDatos = array_values($conteoEstados);
        }

        // Enviamos todo a la vista
        return view('proyectos.tareas', compact(
            'proyecto', 'tareas', 'graficaLabels', 'graficaDatos', 
            'tipos', 'estados', 'asignados', 'prioridades',
            'selectedTipo', 'selectedEstado', 'selectedAsignado', 'selectedSearch', 'selectedPrioridad', 'selectedSort'
        ));
    }

    public function exportarPdf($id)
    {
        $rutaProyectos = storage_path('app/proyectos_ugr.json');
        $proyecto = null;
        if (\Illuminate\Support\Facades\File::exists($rutaProyectos)) {
            $proyectosData = json_decode(\Illuminate\Support\Facades\File::get($rutaProyectos), true);
            $proyecto = collect($proyectosData['_embedded']['elements'] ?? [])->firstWhere('id', (int)$id);
        }

        if (!$proyecto) {
            abort(404, 'Proyecto no encontrado');
        }

        $rutaTareas = storage_path('app/tareas_ugr.json');
        $tareas = [];
        if (\Illuminate\Support\Facades\File::exists($rutaTareas)) {
            $tareasData = json_decode(\Illuminate\Support\Facades\File::get($rutaTareas), true);
            $todasLasTareas = $tareasData['_embedded']['elements'] ?? [];

            $tareas = array_filter($todasLasTareas, function($tarea) use ($id) {
                $enlaceProyecto = $tarea['_links']['project']['href'] ?? '';
                return str_ends_with($enlaceProyecto, '/' . $id);
            });
        }

        // Cargamos una vista especial para el PDF y le pasamos los datos
        $pdf = Pdf::loadView('proyectos.pdf', compact('proyecto', 'tareas'));
        
        // Forzamos la descarga del archivo con un nombre dinámico
        return $pdf->download('informe_UGR_proyecto_' . $proyecto['id'] . '.pdf');
    }
}
