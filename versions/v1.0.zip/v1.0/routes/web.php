<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

// RUTAS DE PROYECTOS
Route::get('/', function () {
    $rutaProyectos = storage_path('app/proyectos_ugr.json');
    $rutaTareas = storage_path('app/tareas_ugr.json');

    $totalProyectos = 0;
    $totalTareas = 0;
    $ultimosProyectos = [];
    $graficaLabels = [];
    $graficaDatos = [];

    // 1. Procesar PROYECTOS
    if (File::exists($rutaProyectos)) {
        $data = json_decode(File::get($rutaProyectos), true);
        $proyectos = $data['_embedded']['elements'] ?? [];
        $totalProyectos = count($proyectos);
        
        // Cogemos solo los 3 primeros para el widget de la Home
        $ultimosProyectos = collect($proyectos)->take(3)->all();
    }

    // 2. Procesar TAREAS (Para la gráfica global)
    if (File::exists($rutaTareas)) {
        $data = json_decode(File::get($rutaTareas), true);
        $tareas = $data['_embedded']['elements'] ?? [];
        $totalTareas = count($tareas);

        // Contamos los estados de TODAS las tareas
        $conteoEstados = [];
        foreach ($tareas as $tarea) {
            $estado = $tarea['_links']['status']['title'] ?? 'Desconocido';
            if (!isset($conteoEstados[$estado])) {
                $conteoEstados[$estado] = 0;
            }
            $conteoEstados[$estado]++;
        }

        // Preparamos los datos para Chart.js
        $graficaLabels = array_keys($conteoEstados);
        $graficaDatos = array_values($conteoEstados);
    }

    return view('welcome', compact(
        'totalProyectos', 'totalTareas', 'ultimosProyectos', 
        'graficaLabels', 'graficaDatos'
    ));
});

// Cuando entremos a localhost:8000/proyectos, cargará la interfaz
Route::get('/proyectos', [ProjectController::class, 'index'])->name('proyectos.index');

// Ruta para ver un proyecto en detalle (el {id} es dinámico)
Route::get('/proyectos/{id}', [ProjectController::class, 'show'])->name('proyectos.show');

// Ruta para ver las tareas (Work Packages) de un proyecto concreto
Route::get('/proyectos/{id}/tareas', [ProjectController::class, 'tareas'])->name('proyectos.tareas');

// RUTAS DE AUTENTICACIÓN 

// 1. Mostrar el formulario (GET)
Route::view('/login', 'auth.login')->name('login');

// 2. Recibir los datos del formulario (POST)
Route::post('/login', [AuthController::class, 'login']);

// 3. Cerrar sesión (POST)
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Ruta para exportar un proyecto a PDF
Route::get('/proyectos/{id}/pdf', [App\Http\Controllers\ProjectController::class, 'exportarPdf'])->name('proyectos.pdf');

// Ruta para el calendario
Route::get('/calendario', function () {
    $rutaTareas = storage_path('app/tareas_ugr.json');
    $eventos = [];

    if (\Illuminate\Support\Facades\File::exists($rutaTareas)) {
        $data = json_decode(\Illuminate\Support\Facades\File::get($rutaTareas), true);
        $tareas = $data['_embedded']['elements'] ?? [];

        foreach ($tareas as $tarea) {
            // Solo añadimos la tarea si tiene fecha de inicio
            if (!empty($tarea['startDate'])) {
                
                // Extraemos el ID del proyecto de la URL para que al hacer clic nos lleve a él
                $hrefProyecto = $tarea['_links']['project']['href'] ?? '';
                $partesUrl = explode('/', $hrefProyecto);
                $proyectoId = end($partesUrl);

                // FullCalendar no incluye el último día (es exclusivo), así que le sumamos 1 día a la fecha fin si existe
                $fechaFin = $tarea['startDate'];
                if (!empty($tarea['dueDate'])) {
                    $fechaFin = date('Y-m-d', strtotime($tarea['dueDate'] . ' +1 day'));
                }

                // Determinamos el color según el estado
                $estado = $tarea['_links']['status']['title'] ?? '';
                $color = match($estado) {
                    'New' => '#3B82F6',         // Azul
                    'In progress' => '#10B981', // Verde
                    'Closed' => '#6B7280',      // Gris
                    default => '#6366F1'        // Índigo por defecto
                };

                $eventos[] = [
                    'title' => $tarea['subject'],
                    'start' => $tarea['startDate'],
                    'end'   => $fechaFin,
                    'url'   => url('/proyectos/' . $proyectoId),
                    'backgroundColor' => $color,
                    'borderColor' => $color,
                ];
            }
        }
    }

    return view('calendario', compact('eventos'));
})->name('calendario');

// Ruta para la búsqueda global de proyectos y tareas
Route::get('/buscar', function (Request $request) {
    $query = strtolower($request->query('q', ''));
    $resultadosProyectos = [];
    $resultadosTareas = [];

    // Solo buscamos si el usuario ha escrito algo
    if (!empty($query)) {
        // 1. Buscar en Proyectos
        $rutaProyectos = storage_path('app/proyectos_ugr.json');
        if (\Illuminate\Support\Facades\File::exists($rutaProyectos)) {
            $proyectos = json_decode(\Illuminate\Support\Facades\File::get($rutaProyectos), true)['_embedded']['elements'] ?? [];
            $resultadosProyectos = array_filter($proyectos, function($p) use ($query) {
                // Buscamos por nombre de proyecto o por ID
                return str_contains(strtolower($p['name'] ?? ''), $query) || str_contains((string)$p['id'], $query);
            });
        }

        // 2. Buscar en Tareas
        $rutaTareas = storage_path('app/tareas_ugr.json');
        if (\Illuminate\Support\Facades\File::exists($rutaTareas)) {
            $tareas = json_decode(\Illuminate\Support\Facades\File::get($rutaTareas), true)['_embedded']['elements'] ?? [];
            $resultadosTareas = array_filter($tareas, function($t) use ($query) {
                // Buscamos por asunto de la tarea o por ID
                return str_contains(strtolower($t['subject'] ?? ''), $query) || str_contains((string)$t['id'], $query);
            });
        }
    }

    return view('buscar', compact('query', 'resultadosProyectos', 'resultadosTareas'));
})->name('buscar');

// Ruta para mostrar el detalle de una tarea concreta
Route::get('/tareas/{id}', function ($id) {
    $rutaTareas = storage_path('app/tareas_ugr.json');
    $tareas = \Illuminate\Support\Facades\File::exists($rutaTareas) 
        ? json_decode(\Illuminate\Support\Facades\File::get($rutaTareas), true)['_embedded']['elements'] ?? [] 
        : [];
        
    // Buscamos la tarea exacta por su ID
    $tarea = collect($tareas)->firstWhere('id', (int)$id);
    
    if (!$tarea) {
        abort(404, 'Tarea no encontrada');
    }

    return view('proyectos.tarea', compact('tarea'));
})->name('tareas.show');

// Ruta para ejecutar el comando de sincronización desde la web (AJAX)
Route::post('/api/sincronizar', function () {
    try {
        Artisan::call('ugr:update');
        return response()->json([
            'success' => true, 
            'message' => 'Sincronización completada con éxito'
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'success' => false, 
            'message' => 'Error: ' . $e->getMessage()
        ], 500);
    }
})->name('api.sync');

// Formulario de registro
Route::get('/registro', function () {
    return view('auth.register');
})->name('registro')->middleware('guest');

// Procesar los datos de creación de usuario
Route::post('/registro', function (Request $request) {
    // Validamos que los datos sean correctos
    $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|string|email|max:255|unique:users',
        'password' => 'required|string|min:8|confirmed', // 'confirmed' exige el campo password_confirmation
    ], [
        'email.unique' => 'Este correo ya está registrado.',
        'password.confirmed' => 'Las contraseñas no coinciden.',
        'password.min' => 'La contraseña debe tener al menos 8 caracteres.'
    ]);

    // Creamos el usuario en la base de datos
    $user = User::create([
        'name' => $request->name,
        'email' => $request->email,
        'password' => Hash::make($request->password),
    ]);

    // Lo iniciamos sesión automáticamente
    Auth::login($user);

    // Lo mandamos al Centro de Mando
    return redirect('/');
})->middleware('guest');