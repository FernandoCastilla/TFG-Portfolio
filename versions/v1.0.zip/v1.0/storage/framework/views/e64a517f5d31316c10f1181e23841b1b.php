<?php $__env->startSection('content'); ?>
<div class="max-w-md mx-auto bg-white p-8 rounded-2xl shadow-lg border border-gray-100 mt-10 relative overflow-hidden">
    <div class="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-500 to-blue-500"></div>

    <div class="text-center mb-8 mt-4">
        <h1 class="text-3xl font-extrabold text-gray-800">Crear Cuenta</h1>
        <p class="text-gray-500 mt-2">Regístrate para acceder al UGR Tracker</p>
    </div>

    <form method="POST" action="<?php echo e(route('registro')); ?>" class="space-y-6">
        <?php echo csrf_field(); ?>

        <div>
            <label for="name" class="block text-sm font-bold text-gray-700 mb-1">Nombre completo</label>
            <input id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" required autofocus
                class="w-full border-2 border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors bg-gray-50 focus:bg-white">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs font-bold mt-1 block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="email" class="block text-sm font-bold text-gray-700 mb-1">Correo electrónico UGR</label>
            <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required
                class="w-full border-2 border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors bg-gray-50 focus:bg-white">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs font-bold mt-1 block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="password" class="block text-sm font-bold text-gray-700 mb-1">Contraseña</label>
            <input id="password" type="password" name="password" required
                class="w-full border-2 border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors bg-gray-50 focus:bg-white">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs font-bold mt-1 block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="password_confirmation" class="block text-sm font-bold text-gray-700 mb-1">Confirmar Contraseña</label>
            <input id="password_confirmation" type="password" name="password_confirmation" required
                class="w-full border-2 border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors bg-gray-50 focus:bg-white">
        </div>

        <div class="pt-2">
            <button type="submit" class="w-full flex justify-center py-3 px-4 rounded-xl shadow-md text-base font-bold text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all transform hover:-translate-y-0.5">
                Completar Registro
            </button>
        </div>
    </form>

    <div class="mt-8 text-center border-t border-gray-100 pt-6">
        <p class="text-sm text-gray-600">
            ¿Ya tienes una cuenta? 
            <a href="<?php echo e(url('/login')); ?>" class="font-bold text-indigo-600 hover:text-indigo-800 transition-colors">Inicia sesión aquí</a>
        </p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/auth/register.blade.php ENDPATH**/ ?>