<?php $__env->startSection('content'); ?>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <div class="max-w-7xl mx-auto">

        <div class="bg-gradient-to-br from-gray-900 via-indigo-900 to-indigo-800 rounded-2xl p-8 mb-8 text-white shadow-xl relative overflow-hidden">
            <div class="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-white opacity-5 rounded-full blur-3xl"></div>
            
            <div class="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div>
                    <h1 class="text-3xl md:text-4xl font-extrabold mb-2 tracking-tight">Centro de Mando UGR</h1>
                    <p class="text-indigo-200 text-lg max-w-xl">
                        Monitorización en tiempo real de Objetivos, KPIs y Work Packages del Vicerrectorado.
                    </p>
                </div>
                
                <button id="btn-sync" onclick="sincronizarDatos()" class="group relative bg-indigo-500 hover:bg-indigo-400 text-white font-bold py-3 px-6 rounded-xl shadow-lg transition-all flex items-center gap-3 overflow-hidden border border-indigo-400 hover:border-white">
                    <svg id="sync-icon" class="w-6 h-6 transition-transform group-hover:rotate-180 duration-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                    </svg>
                    <span id="sync-text">Sincronizar con OpenProject</span>
                </button>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex items-center hover:shadow-md transition-shadow">
                <div class="p-4 bg-indigo-50 text-indigo-600 rounded-xl mr-5">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 002-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                    </svg>
                </div>
                <div>
                    <p class="text-sm font-bold text-gray-400 uppercase tracking-wider">Proyectos Activos</p>
                    <p class="text-3xl font-black text-gray-800"><?php echo e($totalProyectos); ?></p>
                </div>
            </div>

            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex items-center hover:shadow-md transition-shadow">
                <div class="p-4 bg-orange-50 text-orange-600 rounded-xl mr-5">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path>
                    </svg>
                </div>
                <div>
                    <p class="text-sm font-bold text-gray-400 uppercase tracking-wider">Tareas (W.P.)</p>
                    <p class="text-3xl font-black text-gray-800"><?php echo e($totalTareas); ?></p>
                </div>
            </div>

            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex items-center hover:shadow-md transition-shadow">
                <div class="p-4 bg-green-50 text-green-600 rounded-xl mr-5">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <div>
                    <p class="text-sm font-bold text-gray-400 uppercase tracking-wider">API UGR</p>
                    <?php if($totalProyectos > 0): ?>
                        <p class="text-xl font-black text-green-600 uppercase">Conectada</p>
                        <p class="text-xs text-green-500 font-medium mt-1">Sincronización OK</p>
                    <?php else: ?>
                        <p class="text-xl font-black text-red-600 uppercase">Sin Datos</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden flex flex-col">
                <div class="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                    <h2 class="text-lg font-bold text-gray-800">Últimos Proyectos Detectados</h2>
                    <a href="<?php echo e(route('proyectos.index')); ?>" class="text-sm font-bold text-indigo-600 hover:text-indigo-800 transition-colors">Ver todos &rarr;</a>
                </div>
                <div class="divide-y divide-gray-100 flex-1 overflow-y-auto" style="max-height: 400px;">
                    <?php $__empty_1 = true; $__currentLoopData = $ultimosProyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="p-5 hover:bg-indigo-50/30 transition flex justify-between items-center group">
                            <div>
                                <p class="text-xs text-indigo-400 font-mono font-bold mb-1">PROYECTO #<?php echo e($proyecto['id']); ?></p>
                                <h3 class="text-md font-bold text-gray-800 group-hover:text-indigo-700 transition-colors"><?php echo e($proyecto['name']); ?></h3>
                            </div>
                            <a href="<?php echo e(route('proyectos.show', $proyecto['id'])); ?>" class="opacity-0 group-hover:opacity-100 bg-white text-indigo-600 border border-indigo-200 hover:bg-indigo-600 hover:text-white px-4 py-2 rounded-lg text-sm font-bold transition shadow-sm">
                                Abrir
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="p-6 text-center text-gray-500 text-sm italic">
                            No hay proyectos disponibles. Pulsa en sincronizar.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 flex flex-col">
                <h2 class="text-lg font-bold text-gray-800 mb-1">Distribución Global</h2>
                <p class="text-sm text-gray-500 mb-8">Estado de todos los Work Packages del Vicerrectorado.</p>
                
                <div class="relative w-full flex-1 flex items-center justify-center min-h-[300px]">
                    <?php if(count($graficaDatos) > 0): ?>
                        <canvas id="graficaGlobal"></canvas>
                    <?php else: ?>
                        <div class="text-center">
                            <svg class="w-16 h-16 text-gray-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z"></path></svg>
                            <p class="text-gray-400 font-medium">No hay datos para la gráfica.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Inicializar Gráfica
            const labels = <?php echo json_encode($graficaLabels); ?>;
            const datos = <?php echo json_encode($graficaDatos); ?>;

            if (datos.length > 0) {
                const ctx = document.getElementById('graficaGlobal').getContext('2d');
                new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: labels,
                        datasets: [{
                            data: datos,
                            backgroundColor: [
                                '#4F46E5', '#10B981', '#F59E0B', '#EF4444', '#3B82F6', '#8B5CF6', '#EC4899', '#14B8A6', '#F97316', '#64748B'
                            ],
                            borderWidth: 0,
                            hoverOffset: 8
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: { padding: 20, usePointStyle: true, font: { family: 'sans-serif', weight: 'bold' } }
                            }
                        },
                        cutout: '75%'
                    }
                });
            }
        });

        // Función AJAX para el botón de sincronización
        function sincronizarDatos() {
            const btn = document.getElementById('btn-sync');
            const icon = document.getElementById('sync-icon');
            const text = document.getElementById('sync-text');

            // Cambiar UI a "Cargando"
            btn.disabled = true;
            btn.classList.replace('bg-indigo-500', 'bg-indigo-800');
            icon.classList.add('animate-spin');
            text.innerText = 'Sincronizando...';

            // Llamada a la API interna
            fetch('<?php echo e(route('api.sync')); ?>', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Accept': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    text.innerText = '¡Actualizado!';
                    btn.classList.replace('bg-indigo-800', 'bg-green-500');
                    icon.classList.remove('animate-spin');
                    
                    // Recargar la página después de 1.5 segundos para ver los nuevos datos
                    setTimeout(() => window.location.reload(), 1500);
                } else {
                    alert('Hubo un error al sincronizar: ' + data.message);
                    resetBtn(btn, icon, text);
                }
            })
            .catch(error => {
                alert('Fallo de conexión.');
                resetBtn(btn, icon, text);
            });
        }

        function resetBtn(btn, icon, text) {
            btn.disabled = false;
            btn.classList.replace('bg-indigo-800', 'bg-indigo-500');
            icon.classList.remove('animate-spin');
            text.innerText = 'Sincronizar con OpenProject';
        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>