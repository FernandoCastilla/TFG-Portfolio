<?php $__env->startSection('content'); ?>

<div class="max-w-6xl mx-auto bg-white p-6 rounded-lg shadow-md">
    <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['links' => [
    ['label' => 'Panel Global', 'url' => url('/')],
    ['label' => 'Proyectos UGR']
]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['links' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
    ['label' => 'Panel Global', 'url' => url('/')],
    ['label' => 'Proyectos UGR']
])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>

    <form method="GET" action="<?php echo e(route('proyectos.index')); ?>"
        class="mb-8 bg-gray-50 p-4 rounded border border-gray-200 flex flex-wrap gap-4 items-end">

        <div class="flex-1 min-w-[200px]">
            <label class="block text-gray-700 text-sm font-bold mb-1">Nombre del Proyecto</label>
            <input type="text" name="search" value="<?php echo e($search); ?>" placeholder="Buscar..."
                class="border border-gray-300 p-2 rounded w-full focus:outline-none focus:ring-2 focus:ring-blue-400">
        </div>

        <div>
            <label class="block text-gray-700 text-sm font-bold mb-1">Estado</label>
            <select name="status"
                class="border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
                <option value="">Todos</option>
                <option value="active" <?php echo e($statusFilter === 'active' ? 'selected' : ''); ?>>Solo Activos</option>
                <option value="inactive" <?php echo e($statusFilter === 'inactive' ? 'selected' : ''); ?>>Solo Inactivos</option>
            </select>
        </div>

        <div>
            <label class="block text-gray-700 text-sm font-bold mb-1">Visibilidad</label>
            <select name="visibility"
                class="border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
                <option value="">Todas</option>
                <option value="public" <?php echo e($visibilityFilter === 'public' ? 'selected' : ''); ?>>Públicos</option>
                <option value="private" <?php echo e($visibilityFilter === 'private' ? 'selected' : ''); ?>>Privados</option>
            </select>
        </div>

        <div class="flex gap-2">
            <button type="submit"
                class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded transition h-[42px]">
                Aplicar Filtros
            </button>
            <a href="<?php echo e(route('proyectos.index')); ?>"
                class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-6 rounded transition h-[42px] flex items-center">
                Limpiar
            </a>
        </div>
    </form>

    <div class="overflow-x-auto">
        
        <?php
            $padres = [];
            $hijos = [];

            // 1. Separamos padres de hijos
            foreach($proyectos as $proyecto) {
                $parentHref = $proyecto['_links']['parent']['href'] ?? null;
                if ($parentHref && str_contains($parentHref, '/api/v3/projects/')) {
                    $parentId = basename($parentHref);
                    $hijos[$parentId][] = $proyecto;
                } else {
                    $padres[] = $proyecto;
                }
            }

            // 2. Reconstruimos la lista
            $proyectosOrdenados = [];
            foreach($padres as $padre) {
                $padre['es_hijo'] = false;
                $proyectosOrdenados[] = $padre;
                
                $padreId = $padre['id'];
                if (isset($hijos[$padreId])) {
                    foreach($hijos[$padreId] as $hijo) {
                        $hijo['es_hijo'] = true;
                        $proyectosOrdenados[] = $hijo;
                    }
                    unset($hijos[$padreId]);
                }
            }
            
            // 3. Huérfanos (por si acaso)
            foreach($hijos as $grupoHijos) {
                foreach($grupoHijos as $hijo) {
                    $hijo['es_hijo'] = true;
                    $proyectosOrdenados[] = $hijo;
                }
            }
        ?>

        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-gray-800 text-white">
                    <th class="p-3 border-b-2">ID</th>
                    <th class="p-3 border-b-2">Nombre del Proyecto</th>
                    <th class="p-3 border-b-2">Fecha de Creación</th>
                    <th class="p-3 border-b-2 text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $proyectosOrdenados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-100 transition border-b <?php echo e($proyecto['es_hijo'] ? 'bg-gray-50' : ''); ?>">
                        
                        <td class="p-3 text-gray-600">
                            <?php if($proyecto['es_hijo']): ?>
                                <div class="flex items-center gap-2 pl-4 text-gray-400" title="Subproyecto">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"></path></svg>
                                    <span>#<?php echo e($proyecto['id']); ?></span>
                                </div>
                            <?php else: ?>
                                <span class="font-medium">#<?php echo e($proyecto['id']); ?></span>
                            <?php endif; ?>
                        </td>

                        <td class="p-3 font-semibold <?php echo e($proyecto['es_hijo'] ? 'text-gray-600 pl-8' : 'text-gray-800'); ?>">
                            <?php echo e($proyecto['name']); ?>

                        </td>

                        <td class="p-3 text-gray-600"><?php echo e(date('d/m/Y', strtotime($proyecto['createdAt']))); ?></td>
                        
                        <td class="p-3 text-center">
                            <a href="<?php echo e(route('proyectos.show', $proyecto['id'])); ?>"
                                class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded text-sm inline-block shadow-sm">
                                Ver Detalles
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="p-6 text-center text-gray-500 text-lg">
                            No se encontraron proyectos con ese filtro.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/proyectos/index.blade.php ENDPATH**/ ?>