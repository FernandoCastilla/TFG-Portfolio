<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto">
        
        <div class="mb-4">
            <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['links' => [
                ['label' => 'Panel Global', 'url' => url('/')],
                ['label' => 'Resultados de Búsqueda', 'url' => null],
            ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['links' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                ['label' => 'Panel Global', 'url' => url('/')],
                ['label' => 'Resultados de Búsqueda', 'url' => null],
            ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
        </div>

        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-800">
                Resultados para: <span class="text-indigo-600">"<?php echo e($query); ?>"</span>
            </h1>
            <p class="text-gray-600 mt-2">
                Se han encontrado <?php echo e(count($resultadosProyectos)); ?> proyectos y <?php echo e(count($resultadosTareas)); ?> tareas.
            </p>
        </div>

        <?php if(empty($query)): ?>
            <div class="bg-yellow-50 text-yellow-800 p-6 rounded-xl border border-yellow-200 text-center">
                <p class="font-bold text-lg">No has escrito nada en el buscador.</p>
                <p class="text-sm">Escribe un ID, el nombre de un proyecto o el asunto de una tarea en el menú lateral.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                    <div class="bg-gray-50 p-4 border-b border-gray-200">
                        <h2 class="font-bold text-gray-800 flex items-center gap-2">
                            <svg class="w-5 h-5 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path></svg>
                            Proyectos Encontrados (<?php echo e(count($resultadosProyectos)); ?>)
                        </h2>
                    </div>
                    <div class="divide-y divide-gray-100">
                        <?php $__empty_1 = true; $__currentLoopData = $resultadosProyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="<?php echo e(route('proyectos.show', $proyecto['id'])); ?>" class="block p-4 hover:bg-indigo-50 transition">
                                <span class="text-xs font-mono text-gray-400 block mb-1">ID: #<?php echo e($proyecto['id']); ?></span>
                                <span class="font-semibold text-indigo-700"><?php echo e($proyecto['name']); ?></span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="p-6 text-center text-gray-500 text-sm">No hay coincidencias en proyectos.</div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                    <div class="bg-gray-50 p-4 border-b border-gray-200">
                        <h2 class="font-bold text-gray-800 flex items-center gap-2">
                            <svg class="w-5 h-5 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path></svg>
                            Tareas Encontradas (<?php echo e(count($resultadosTareas)); ?>)
                        </h2>
                    </div>
                    <div class="divide-y divide-gray-100">
                        <?php $__empty_1 = true; $__currentLoopData = $resultadosTareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                // Extraer el ID del proyecto de la URL de la tarea para crear el enlace
                                $hrefProyecto = $tarea['_links']['project']['href'] ?? '';
                                $proyectoId = explode('/', $hrefProyecto);
                                $proyectoId = end($proyectoId);
                            ?>
                            <a href="<?php echo e(route('proyectos.show', $proyectoId)); ?>" class="block p-4 hover:bg-orange-50 transition">
                                <span class="text-xs font-mono text-gray-400 block mb-1">
                                    ID: #<?php echo e($tarea['id']); ?> | <span class="text-<?php echo e($tarea['_links']['status']['title'] === 'Closed' ? 'green' : 'gray'); ?>-500"><?php echo e($tarea['_links']['status']['title'] ?? ''); ?></span>
                                </span>
                                <span class="font-semibold text-gray-800"><?php echo e($tarea['subject']); ?></span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="p-6 text-center text-gray-500 text-sm">No hay coincidencias en tareas.</div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/buscar.blade.php ENDPATH**/ ?>