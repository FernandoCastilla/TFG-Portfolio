@extends('layouts.app')

@section('content')

<style>
    .op-content p { margin-bottom: 0.75rem; }
    .op-content table { width: 100%; border-collapse: collapse; margin-top: 1rem; margin-bottom: 1rem; background-color: white; }
    .op-content td, .op-content th { border: 1px solid #d1d5db; padding: 0.75rem; vertical-align: top; }
    .op-content ul { list-style-type: disc; padding-left: 1.5rem; margin-bottom: 0.75rem; }
</style>

<div class="max-w-5xl mx-auto">
    <div class="mb-6">
        <x-breadcrumb :links="[
            ['label' => 'Panel Global', 'url' => url('/')],
            ['label' => 'Volver atrás', 'url' => url()->previous()],
            ['label' => 'Tarea #' . $tarea['id']]
        ]" />
    </div>

    <div class="bg-white p-8 rounded-t-xl shadow-sm border border-gray-200 border-b-0">
        <div class="flex flex-wrap items-center gap-3 mb-4">
            <span class="bg-gray-100 text-gray-700 text-xs px-3 py-1 rounded border border-gray-200 uppercase font-bold tracking-wider">
                {{ $tarea['_links']['type']['title'] ?? 'Tarea' }}
            </span>
            <span class="bg-indigo-100 text-indigo-800 text-xs font-bold px-3 py-1 rounded-full">
                {{ $tarea['_links']['status']['title'] ?? 'N/A' }}
            </span>
            @if(isset($tarea['_links']['priority']['title']))
                @php
                    $prioridad = $tarea['_links']['priority']['title'];
                    $colorPrio = match($prioridad) {
                        'Inmediata', 'Alta' => 'bg-red-100 text-red-800',
                        'Baja' => 'bg-blue-100 text-blue-800',
                        default => 'bg-yellow-100 text-yellow-800'
                    };
                @endphp
                <span class="{{ $colorPrio }} text-xs font-bold px-3 py-1 rounded-full">
                    Prioridad: {{ $prioridad }}
                </span>
            @endif
        </div>

        <h1 class="text-3xl font-bold text-gray-800 mb-2">{{ $tarea['subject'] }}</h1>
        <p class="text-gray-500 font-mono text-sm mb-6">ID: #{{ $tarea['id'] }}</p>

        @php $porcentaje = $tarea['percentageDone'] ?? 0; @endphp
        <div class="mb-2 flex justify-between items-end">
            <span class="text-sm font-bold text-gray-700">Progreso de la tarea</span>
            <span class="text-sm font-bold {{ $porcentaje == 100 ? 'text-green-600' : 'text-indigo-600' }}">{{ $porcentaje }}%</span>
        </div>
        <div class="w-full bg-gray-200 rounded-full h-3 border border-gray-300">
            <div class="{{ $porcentaje == 100 ? 'bg-green-500' : 'bg-indigo-500' }} h-3 rounded-full transition-all duration-500" style="width: {{ $porcentaje }}%"></div>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-0">
        
        <div class="md:col-span-2 bg-white p-8 rounded-bl-xl shadow-sm border border-gray-200">
            <h3 class="text-lg font-bold text-gray-700 mb-4 border-b pb-2">Descripción de la Tarea</h3>
            <div class="text-gray-700 op-content">
                @if(!empty($tarea['description']['html']))
                    {!! $tarea['description']['html'] !!}
                @elseif(!empty($tarea['description']['raw']))
                    <p>{{ $tarea['description']['raw'] }}</p>
                @else
                    <p class="text-gray-400 italic">Esta tarea no tiene descripción detallada.</p>
                @endif
            </div>
        </div>

        <div class="bg-gray-50 p-8 rounded-br-xl shadow-sm border border-gray-200 border-l-0">
            <h3 class="text-lg font-bold text-gray-700 mb-4 border-b border-gray-200 pb-2">Detalles</h3>
            
            <div class="space-y-5">
                <div>
                    <span class="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Asignado a</span>
                    @if(isset($tarea['_links']['assignee']['title']))
                        <div class="flex items-center gap-2">
                            <div class="w-8 h-8 rounded-full bg-indigo-200 text-indigo-700 flex items-center justify-center text-sm font-bold">
                                {{ strtoupper(substr($tarea['_links']['assignee']['title'], 0, 1)) }}
                            </div>
                            <span class="font-medium text-gray-800">{{ $tarea['_links']['assignee']['title'] }}</span>
                        </div>
                    @else
                        <span class="text-gray-500 italic">Sin asignar</span>
                    @endif
                </div>

                <div>
                    <span class="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Creado por</span>
                    <span class="font-medium text-gray-800">{{ $tarea['_links']['author']['title'] ?? 'Desconocido' }}</span>
                </div>

                <div class="bg-white p-3 rounded border border-gray-200 shadow-sm">
                    <div class="mb-2">
                        <span class="block text-xs font-bold text-gray-500 uppercase">Fecha Inicio</span>
                        <span class="font-medium text-gray-800">
                            {{ !empty($tarea['startDate']) ? date('d/m/Y', strtotime($tarea['startDate'])) : 'No definida' }}
                        </span>
                    </div>
                    <div>
                        <span class="block text-xs font-bold text-gray-500 uppercase">Fecha Fin (Due Date)</span>
                        <span class="font-medium text-gray-800">
                            {{ !empty($tarea['dueDate']) ? date('d/m/Y', strtotime($tarea['dueDate'])) : 'No definida' }}
                        </span>
                    </div>
                </div>
                
                @if(isset($tarea['_links']['parent']['title']))
                <div class="mt-4 p-3 bg-indigo-50 border border-indigo-100 rounded">
                    <span class="block text-xs font-bold text-indigo-500 uppercase mb-1">Pertenece a (Épica/Padre)</span>
                    <span class="font-medium text-indigo-700 text-sm">{{ $tarea['_links']['parent']['title'] }}</span>
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

@endsection