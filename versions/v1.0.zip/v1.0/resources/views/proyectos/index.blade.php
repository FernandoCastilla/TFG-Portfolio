@extends('layouts.app')

@section('content')

<div class="max-w-6xl mx-auto bg-white p-6 rounded-lg shadow-md">
    <x-breadcrumb :links="[
    ['label' => 'Panel Global', 'url' => url('/')],
    ['label' => 'Proyectos UGR']
]" />

    <form method="GET" action="{{ route('proyectos.index') }}"
        class="mb-8 bg-gray-50 p-4 rounded border border-gray-200 flex flex-wrap gap-4 items-end">

        <div class="flex-1 min-w-[200px]">
            <label class="block text-gray-700 text-sm font-bold mb-1">Nombre del Proyecto</label>
            <input type="text" name="search" value="{{ $search }}" placeholder="Buscar..."
                class="border border-gray-300 p-2 rounded w-full focus:outline-none focus:ring-2 focus:ring-blue-400">
        </div>

        <div>
            <label class="block text-gray-700 text-sm font-bold mb-1">Estado</label>
            <select name="status"
                class="border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
                <option value="">Todos</option>
                <option value="active" {{ $statusFilter === 'active' ? 'selected' : '' }}>Solo Activos</option>
                <option value="inactive" {{ $statusFilter === 'inactive' ? 'selected' : '' }}>Solo Inactivos</option>
            </select>
        </div>

        <div>
            <label class="block text-gray-700 text-sm font-bold mb-1">Visibilidad</label>
            <select name="visibility"
                class="border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
                <option value="">Todas</option>
                <option value="public" {{ $visibilityFilter === 'public' ? 'selected' : '' }}>Públicos</option>
                <option value="private" {{ $visibilityFilter === 'private' ? 'selected' : '' }}>Privados</option>
            </select>
        </div>

        <div class="flex gap-2">
            <button type="submit"
                class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded transition h-[42px]">
                Aplicar Filtros
            </button>
            <a href="{{ route('proyectos.index') }}"
                class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-6 rounded transition h-[42px] flex items-center">
                Limpiar
            </a>
        </div>
    </form>

    <div class="overflow-x-auto">
        
        @php
            $padres = [];
            $hijos = [];

            // 1. Separamos padres de hijos
            foreach($proyectos as $proyecto) {
                $parentHref = $proyecto['_links']['parent']['href'] ?? null;
                if ($parentHref && str_contains($parentHref, '/api/v3/projects/')) {
                    $parentId = basename($parentHref);
                    $hijos[$parentId][] = $proyecto;
                } else {
                    $padres[] = $proyecto;
                }
            }

            // 2. Reconstruimos la lista
            $proyectosOrdenados = [];
            foreach($padres as $padre) {
                $padre['es_hijo'] = false;
                $proyectosOrdenados[] = $padre;
                
                $padreId = $padre['id'];
                if (isset($hijos[$padreId])) {
                    foreach($hijos[$padreId] as $hijo) {
                        $hijo['es_hijo'] = true;
                        $proyectosOrdenados[] = $hijo;
                    }
                    unset($hijos[$padreId]);
                }
            }
            
            // 3. Huérfanos (por si acaso)
            foreach($hijos as $grupoHijos) {
                foreach($grupoHijos as $hijo) {
                    $hijo['es_hijo'] = true;
                    $proyectosOrdenados[] = $hijo;
                }
            }
        @endphp

        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-gray-800 text-white">
                    <th class="p-3 border-b-2">ID</th>
                    <th class="p-3 border-b-2">Nombre del Proyecto</th>
                    <th class="p-3 border-b-2">Fecha de Creación</th>
                    <th class="p-3 border-b-2 text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
                @forelse($proyectosOrdenados as $proyecto)
                    <tr class="hover:bg-gray-100 transition border-b {{ $proyecto['es_hijo'] ? 'bg-gray-50' : '' }}">
                        
                        <td class="p-3 text-gray-600">
                            @if($proyecto['es_hijo'])
                                <div class="flex items-center gap-2 pl-4 text-gray-400" title="Subproyecto">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"></path></svg>
                                    <span>#{{ $proyecto['id'] }}</span>
                                </div>
                            @else
                                <span class="font-medium">#{{ $proyecto['id'] }}</span>
                            @endif
                        </td>

                        <td class="p-3 font-semibold {{ $proyecto['es_hijo'] ? 'text-gray-600 pl-8' : 'text-gray-800' }}">
                            {{ $proyecto['name'] }}
                        </td>

                        <td class="p-3 text-gray-600">{{ date('d/m/Y', strtotime($proyecto['createdAt'])) }}</td>
                        
                        <td class="p-3 text-center">
                            <a href="{{ route('proyectos.show', $proyecto['id']) }}"
                                class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded text-sm inline-block shadow-sm">
                                Ver Detalles
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" class="p-6 text-center text-gray-500 text-lg">
                            No se encontraron proyectos con ese filtro.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

@endsection