<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TFG Dashboard - Fernando</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-50 font-sans antialiased text-gray-900">

    <aside class="fixed top-0 left-0 w-64 h-screen bg-gray-900 text-white flex flex-col shadow-2xl z-20">
        <div class="h-16 flex items-center justify-center border-b border-gray-800 bg-gray-950">
            <h1 class="text-xl font-bold tracking-wider uppercase text-indigo-400">UGR Tracker</h1>
        </div>

        <div class="px-4 py-4 border-b border-gray-800 bg-gray-900">
            <form action="{{ route('buscar') }}" method="GET" class="relative">
                <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                </div>
                <input type="text" name="q" value="{{ request('q') }}" placeholder="Buscar proyecto o tarea..." 
                       class="w-full bg-gray-800 text-sm text-gray-200 border border-gray-700 rounded-lg pl-9 pr-3 py-2 focus:ring-indigo-500 focus:border-indigo-500 placeholder-gray-500 transition-colors">
            </form>
        </div>
        
        <nav class="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
            <a href="{{ url('/') }}"
                class="flex items-center gap-3 px-4 py-3 rounded-lg transition-all {{ request()->is('/') ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:bg-gray-800' }}">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z">
                    </path>
                </svg>
                Panel Global
            </a>

            <a href="{{ route('proyectos.index') }}"
                class="flex items-center gap-3 px-4 py-3 rounded-lg transition-all {{ request()->is('proyectos*') ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:bg-gray-800' }}">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path>
                </svg>
                Proyectos UGR
            </a>

            <a href="{{ route('calendario') }}"
                class="flex items-center gap-3 px-4 py-3 rounded-lg transition-all {{ request()->routeIs('calendario') ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:bg-gray-800' }}">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z">
                    </path>
                </svg>
                Calendario
            </a>
        </nav>
        <div class="p-4 border-t border-gray-800 bg-gray-950">
            @auth
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3 overflow-hidden">
                        <div
                            class="w-9 h-9 flex-shrink-0 rounded-full bg-indigo-500 flex items-center justify-center text-sm font-bold text-white uppercase">
                            {{ substr(auth()->user()->name, 0, 1) }}
                        </div>
                        <div class="text-sm truncate">
                            <p class="font-medium text-gray-200 truncate">{{ auth()->user()->name }}</p>
                        </div>
                    </div>

                    <form method="POST" action="{{ route('logout') }}" class="flex-shrink-0 ml-2">
                        @csrf
                        <button type="submit" class="text-gray-400 hover:text-red-400 transition-colors"
                            title="Cerrar sesión">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1">
                                </path>
                            </svg>
                        </button>
                    </form>
                </div>
            @else
                <a href="{{ route('login') }}"
                    class="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg transition-colors shadow-sm">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1">
                        </path>
                    </svg>
                    Iniciar Sesión
                </a>
            @endauth
        </div>
    </aside>

    <div class="ml-64 flex flex-col min-h-screen">
        <main class="flex-1 p-8 bg-gray-50">
            @yield('content')
        </main>

        <footer class="bg-white border-t border-gray-200 px-8 py-4 flex items-center justify-between mt-auto">
            <p class="text-sm text-gray-500">
                © 2026 UGR Tracker. Trabajo de Fin de Grado - Fernando C.
            </p>

            @php
                // Leemos el estado de la caché. Si no existe (es la primera vez), asumimos false
                $estadoConexion = \Illuminate\Support\Facades\Cache::get('api_conectada', false);
            @endphp

            @if($estadoConexion)
                <div class="flex items-center gap-2 text-xs text-green-700 bg-green-50 px-3 py-1.5 rounded-full border border-green-200 font-medium shadow-sm">
                    <span class="relative flex h-2 w-2">
                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                        <span class="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                    </span>
                    API Conectada: proyectostic.ugr.es
                </div>
            @else
                <div class="flex items-center gap-2 text-xs text-red-700 bg-red-50 px-3 py-1.5 rounded-full border border-red-200 font-medium shadow-sm">
                    <span class="relative flex h-2 w-2">
                        <span class="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                    </span>
                    API Desconectada (Requiere Sincronización)
                </div>
            @endif
        </footer>

    </div>
</body>

</html>