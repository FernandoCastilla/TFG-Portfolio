@extends('layouts.app')

@section('content')
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js'></script>

    <div class="mb-4">
        <x-breadcrumb :links="[
            ['label' => 'Panel Global', 'url' => url('/')],
            ['label' => 'Calendario de Tareas', 'url' => null],
        ]" />
    </div>

    <div class="max-w-7xl mx-auto">

        <div class="mb-6">
            <h1 class="text-3xl font-bold text-gray-800">Calendario de Work Packages</h1>
            <p class="text-gray-600">Vista temporal de todas las tareas planificadas en los proyectos.</p>
        </div>

        <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div class="flex gap-4 mb-4 text-sm">
                <div class="flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-blue-500"></span> Nuevas</div>
                <div class="flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-green-500"></span> En progreso
                </div>
                <div class="flex items-center gap-1"><span class="w-3 h-3 rounded-full bg-gray-500"></span> Cerradas</div>
            </div>

            <div id='calendar'></div>
        </div>

    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var calendarEl = document.getElementById('calendar');

            // Recogemos los eventos de PHP
            var eventos = {!! json_encode($eventos) !!};

            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth', // Vista mensual por defecto
                locale: 'es', // Español
                firstDay: 1, // La semana empieza en Lunes
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,listMonth' // Opciones de vista
                },
                buttonText: {
                    today: 'Hoy',
                    month: 'Mes',
                    week: 'Semana',
                    list: 'Lista'
                },
                events: eventos,
                eventClick: function (info) {
                    // Al hacer clic, que se abra en la misma pestaña la vista del proyecto
                    window.location.href = info.event.url;
                    info.jsEvent.preventDefault(); // Evita el comportamiento por defecto
                }
            });

            calendar.render();
        });
    </script>
@endsection